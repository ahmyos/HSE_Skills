# Operational and Construction Safety Advisor Skill

A downloadable skill for high-risk work controls in operations, maintenance, shutdown, commissioning, construction, and EPC projects.

## Installation
1. Download and extract `operational-construction-safety-skill.zip`.
2. Add the complete folder to the skills directory supported by your Copilot or agent environment.
3. Keep the folder structure unchanged.
4. Align each procedure, permit, limit, competency rule, and technical criterion with the applicable jurisdiction, approved company standard, site conditions, and manufacturer or engineering requirements.

## Example Requests
- Draft an integrated Permit to Work procedure and permit matrix.
- Review a LOTO procedure for isolation and group-lock gaps.
- Create a confined-space entry package and rescue-readiness checklist.
- Prepare a critical-lift review checklist.
- Build a SIMOPS register for construction and commissioning.
- Create an excavation permit and daily inspection form.
- Develop a temporary-works register and approval workflow.
- Prepare a journey management plan and driver/vehicle checklist.
