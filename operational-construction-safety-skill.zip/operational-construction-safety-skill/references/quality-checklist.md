# Operational and Construction Safety Quality Checklist

- [ ] Scope, location, timing, people, and interfaces are clear
- [ ] Current drawings, procedures, plans, and specifications are referenced
- [ ] Hazards, energy sources, and environment are assessed
- [ ] Competent and authorized roles are defined
- [ ] Engineering controls and isolations are verified
- [ ] Permit, certificates, and supporting assessments are linked
- [ ] SIMOPS and adjacent work are checked
- [ ] Equipment is suitable, inspected, and within verified capacity
- [ ] Emergency and rescue arrangements are ready
- [ ] Toolbox talk and field verification are recorded
- [ ] Validity, handover, suspension, extension, and closeout are controlled
- [ ] Changes trigger reassessment and reauthorization
- [ ] Actions, owners, evidence, and effectiveness checks are visible
- [ ] No technical value or legal requirement is invented
