# Operational Control Framework

## Field Control Sequence
- Plan and define
- Risk assess
- Engineer and isolate
- Verify competence and equipment
- Authorize
- Brief
- Execute under supervision
- Monitor change
- Suspend when required
- Inspect, reinstate, and close

## Common Failure Modes
- Permit used as a checklist without field verification
- Isolation points not traced or zero-energy state not proven
- Simultaneous work omitted
- Planned controls treated as implemented
- Rescue planning left until after entry or work begins
- Equipment certification accepted without configuration checks
- Shift handover, suspension, or closeout not controlled
- Temporary works altered without design review
- Journey approved without fatigue, route, or communication controls
