# Permit to Work
- Permit number:
- Type:
- Area and exact location:
- Scope of work:
- Work party and supervisor:
- Start and expiry:
- Linked HIRA/JSA and method statement:
- Linked isolation and specialist certificates:

## Controls
- [ ] Site inspected
- [ ] Energy isolation verified
- [ ] Gas testing requirements confirmed
- [ ] Access, barricade, signage, and exclusion controls ready
- [ ] SIMOPS and conflicting permits checked
- [ ] Emergency and rescue arrangements ready
- [ ] Toolbox talk completed

## Authorization, Suspension, Handover, and Closeout
Record names, roles, dates, times, conditions, and field verification.
