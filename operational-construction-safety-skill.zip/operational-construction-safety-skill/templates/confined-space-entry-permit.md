# Confined Space Entry Permit
- Space and location:
- Purpose and duration:
- Entry supervisor:
- Entrants:
- Attendant:
- Gas tester:
- Rescue provider:

## Verification
- [ ] Space classification confirmed
- [ ] Isolation and zero energy verified
- [ ] Cleaning, purging, and ventilation complete
- [ ] Atmospheric test plan and records attached
- [ ] Communications and access controlled
- [ ] Tools, lighting, PPE, and respiratory protection suitable
- [ ] Rescue plan, equipment, and response capability verified
- [ ] Evacuation triggers understood

## Entry Log and Cancellation
Record entry and exit times, monitoring, changes, suspension, and closeout.
