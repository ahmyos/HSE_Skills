# Excavation Permit
- Location, dimensions, purpose, and duration:
- Drawing and service information:
- Excavation supervisor and competent inspector:

## Controls
- [ ] Services detected, marked, exposed, or isolated as required
- [ ] Soil, groundwater, surcharge, vibration, and adjacent structures assessed
- [ ] Protective system designed and installed where required
- [ ] Safe access, edge protection, spoil, plant, and lifting controls ready
- [ ] Water, atmosphere, traffic, and emergency controls ready
- [ ] Daily and event-triggered inspection arranged

## Inspection and Closeout
Record changing conditions, inspections, backfill, service protection, and reinstatement.
