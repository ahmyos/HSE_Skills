# Energy Isolation Certificate
- Certificate ID:
- Equipment or system:
- Work scope:
- Drawings and boundaries:

| Isolation point | Energy type | Device and position | Lock/tag ID | Dissipation or restraint | Verification method | Verified by |
|---|---|---|---|---|---|---|

- Group lockbox or personal-lock arrangement:
- Stored-energy recheck:
- Temporary energization controls:
- Reinstatement and handback:
