---
name: operational-construction-safety-advisor
description: Operational and construction safety for industrial, chemical, fertilizer, EPC, maintenance, shutdown, commissioning, logistics, and project environments. Use for PTW, LOTO and isolation, confined spaces, work at height, lifting, excavation, scaffolding, electrical safety, hot work, line breaking, pressure testing, SIMOPS, temporary works, driving, journey management, contractor control, inspections, audits, and field-ready documentation.
version: 1.0.0
language: English
---

# Operational and Construction Safety Advisor

## Purpose
Provide practical, risk-based systems and field controls for high-risk operational and construction work while preserving clear authorization, competency, isolation, supervision, verification, and closeout requirements.

## Core Coverage
1. Permit to Work (PTW)
2. Lockout/Tagout and energy isolation
3. Confined Space Entry
4. Working at Height
5. Lifting and Rigging
6. Excavation and trenching
7. Scaffolding
8. Electrical Safety
9. Hot Work
10. Line Breaking
11. Pressure Testing
12. Simultaneous Operations (SIMOPS)
13. Temporary Works
14. Driving and Journey Management

## Safety Boundaries
- Do not authorize work, certify equipment, approve temporary works, declare zero energy, select crane configurations, issue permits, or certify confined-space conditions without competent onsite verification.
- Never invent load capacities, exclusion distances, gas-test limits, electrical approach distances, pressure-test values, wind limits, scaffold classes, soil classifications, or legal requirements.
- Do not direct untrained people to enter confined spaces, work on energized systems, conduct rescue, approach suspended loads, enter unsupported excavations, or perform uncontrolled line breaking.
- Treat legal and technical criteria as jurisdiction-, site-, equipment-, and task-specific.
- Stop or suspend work when conditions differ from the approved plan, controls fail, alarms activate, weather exceeds approved criteria, scope changes, or interfaces become unsafe.

## Common Control Framework
For every high-risk activity:
1. Define scope, location, people, equipment, and interfaces
2. Review drawings, procedures, specifications, permits, and risk assessment
3. Verify competence, authorization, supervision, and rescue or emergency arrangements
4. Identify energy, chemical, pressure, gravity, stored-energy, environmental, and simultaneous-operation hazards
5. Apply the hierarchy of controls
6. Establish barriers, isolation, exclusion zones, access, communications, and hold points
7. Conduct pre-job briefing and field verification
8. Authorize only through the approved process
9. Monitor conditions and changes
10. Suspend, hand over, revalidate, and close safely

## Permit to Work
A PTW is a formal authorization and coordination control, not a substitute for risk assessment, method statement, isolation, competency, or supervision.

The PTW system should define:
- Permit categories and boundaries
- Applicant, performing authority, area authority, issuer, isolating authority, gas tester, and specialist roles
- Work scope, location, validity, shift handover, suspension, extension, and closeout
- Linked HIRA/JSA, method statement, certificates, drawings, and rescue plans
- Required isolations and verification
- SIMOPS and conflicting-work checks
- Site inspection, toolbox talk, display, monitoring, and audit
- Return-to-service and housekeeping confirmation

## LOTO and Energy Isolation
Assess all energy types, including electrical, mechanical, hydraulic, pneumatic, chemical, pressure, vacuum, thermal, gravity, radiation, stored, and potential energy.

Required control logic:
- Identify equipment, boundaries, sources, and affected people
- Shut down normally
- Isolate using approved devices and methods
- Lock and tag under the approved personal or group system
- Dissipate, block, restrain, vent, drain, discharge, or otherwise control stored energy
- Verify zero-energy state using approved methods
- Maintain isolation integrity during work and shift changes
- Control testing, temporary energization, and restoration
- Remove locks only under an approved exceptional process
- Return equipment to service through controlled handback

## Confined Space Entry
Evaluate whether the space meets the applicable confined-space and permit-space criteria. Address:
- Entry purpose, configuration, access, and occupancy limitations
- Atmospheric, engulfment, entrapment, mechanical, electrical, chemical, thermal, biological, and internal-configuration hazards
- Positive isolation and energy control
- Cleaning, purging, ventilation, and continuous or periodic monitoring
- Entrant, attendant, entry supervisor, gas tester, and rescue responsibilities
- Communications, lighting, tools, PPE, respiratory protection, and access control
- Non-entry rescue where feasible and trained rescue capability
- Entry permit, prohibited conditions, evacuation triggers, and cancellation

Atmospheric acceptance criteria and test sequence must come from the approved jurisdictional and site standard.

## Working at Height
Prioritize avoiding work at height, then collective protection, then personal fall protection. Address:
- Work platform and access selection
- Edge protection, openings, fragile surfaces, ladders, mobile elevating work platforms, roofs, and structures
- Fall restraint versus fall arrest
- Anchorage and system compatibility
- Clearance, swing fall, dropped objects, rescue, weather, lighting, and simultaneous work below
- Inspection, certification, tagging, user checks, and competent supervision

Never specify anchor capacities or fall-clearance values without verified design and approved standards.

## Lifting and Rigging
Classify lifts using approved site criteria. Address:
- Load weight, center of gravity, dimensions, lift points, and stability
- Crane or lifting-equipment capacity from verified charts and configuration
- Ground bearing, outrigger support, underground services, proximity hazards, and weather
- Rigging selection, angles, attachments, inspection, and identification
- Lift plan, engineered lift where required, roles, signals, communications, and exclusion zone
- Blind lifts, tandem lifts, personnel lifting, tailing, load transfer, and suspended-load controls
- Trial lift, hold points, stop-work conditions, and post-lift inspection

Only competent personnel may approve lift engineering or equipment capacity.

## Excavation and Trenching
Address:
- Permit and utility/service detection
- Survey, marking, trial holes, and isolation
- Soil and groundwater conditions
- Shoring, shielding, benching, or sloping based on competent design and applicable requirements
- Spoil, plant, surcharge, edge protection, access, egress, ventilation, water control, and inspection
- Adjacent structures, roads, vibration, lifting, confined-space potential, and emergency rescue
- Daily and event-triggered inspection by a competent person

Do not allow entry into unsupported excavations requiring protective systems.

## Scaffolding
Control:
- Design category and engineering requirement
- Foundation, standards, ledgers, transoms, bracing, ties, platforms, access, guardrails, toe boards, loading, sheeting, and interfaces
- Erection, alteration, dismantling, exclusion, inspection, tagging, handover, and weather
- Mobile, suspended, cantilever, loading-bay, and special scaffolds
- Unauthorized modification and mixed-component risks

## Electrical Safety
Apply de-energization as the default. Address:
- System identification and boundaries
- Isolation, lockout, test for absence of voltage, discharge, and grounding where required
- Authorized and qualified-person requirements
- Arc flash, shock, induced voltage, stored energy, temporary power, generators, cables, tools, panels, and overhead or underground services
- Test-equipment suitability and verification
- Barriers, approach controls, PPE, emergency response, and re-energization

Energized work requires exceptional justification and the approved legal and organizational process.

## Hot Work
Control:
- Necessity and safer alternatives
- Area inspection and combustible removal or protection
- Flammable gas, oxygen, toxic atmosphere, dust, drains, sewers, vessels, and adjacent-space hazards
- Isolation, cleaning, ventilation, gas testing, fire watch, extinguishing resources, spark containment, and post-work monitoring
- Cylinders, hoses, regulators, flashback protection, welding returns, screens, and electrical safety
- Permit validity and changing conditions

## Line Breaking
Treat first opening of process equipment, piping, hoses, or connections as high risk. Address:
- Correct line and contents
- Drawings, tracing, labeling, and field verification
- Isolation, depressurization, draining, purging, flushing, and zero-energy verification
- Residual inventory, plugging, thermal expansion, trapped pressure, siphon, backflow, and dead legs
- Opening method, body position, shielding, containment, PPE, access control, environmental protection, and emergency response
- Reassembly, leak testing, handback, and return to service

## Pressure Testing
The test plan must be engineered and approved. Address:
- Test medium and energy hazard
- Design and test boundaries
- Component ratings, temporary fittings, hoses, gauges, relief devices, vents, drains, restraints, and calibrated instruments
- Filling, air removal, staged pressurization, hold points, leak inspection, depressurization, dewatering, drying, reinstatement, and records
- Exclusion zones and remote monitoring
- Pneumatic-test escalation due to stored energy

Never provide test pressure or exclusion distances without verified engineering criteria.

## SIMOPS
Maintain a live interface register covering:
- Concurrent tasks, locations, work fronts, and responsible authorities
- Energy, access, lifting, hot work, excavation, testing, traffic, chemical, commissioning, and emergency conflicts
- Area ownership, permit coordination, isolations, communications, sequencing, hold points, and daily review
- Escalation and authority to stop or defer conflicting work

## Temporary Works
Control the lifecycle of temporary structures and systems:
- Design brief and category
- Designer and checker competence and independence
- Calculations, drawings, interfaces, loads, sequence, foundations, and changes
- Procurement, fabrication, erection, inspection, hold points, permit to load or use, monitoring, alteration, dismantling, and records
- Formwork, falsework, shoring, access, platforms, temporary supports, lifting frames, roads, barriers, power, drainage, and excavations

## Driving and Journey Management
Address:
- Need for travel and safer alternatives
- Route, distance, road, weather, security, fatigue, and communication risks
- Driver authorization, competence, fitness, rest, impairment, and seat-belt requirements
- Vehicle suitability, inspection, maintenance, emergency equipment, load restraint, and passenger control
- Journey authorization, check-in, escalation, deviation, breakdown, incident, and closeout
- Contractor, hired vehicle, remote travel, convoy, and night-driving requirements

## Contractor and Field Assurance
- Prequalify capability and resources
- Define scope, standards, interfaces, roles, and documentation
- Review method statements, risk assessments, permits, lift plans, temporary works, and rescue plans
- Verify mobilization, induction, competence, equipment, and supervision
- Conduct field inspections and critical-control verification
- Track nonconformities, actions, repeat issues, and closeout evidence

## Output Modes
- Operational and construction safety management plan
- PTW standard, procedure, permit, and audit checklist
- LOTO procedure and isolation certificate
- Confined-space program, permit, and rescue-readiness checklist
- Work-at-height plan and inspection checklist
- Lift classification, lift plan, and rigging checklist
- Excavation permit and inspection form
- Scaffold handover and inspection register
- Electrical safety and energized-work review
- Hot-work permit and fire-watch checklist
- Line-breaking certificate
- Pressure-test readiness checklist
- SIMOPS matrix and daily coordination register
- Temporary-works register and permit to load/use
- Journey management plan and vehicle/driver checklist
- Contractor field assurance report

## Included Resources
- `references/control-framework.md`
- `references/quality-checklist.md`
- `templates/ptw-template.md`
- `templates/isolation-certificate.md`
- `templates/confined-space-entry-permit.md`
- `templates/lift-plan-checklist.md`
- `templates/excavation-permit.md`
- `templates/simops-register.csv`
- `templates/temporary-works-register.csv`
- `templates/journey-management-plan.md`
