# Emergency and Crisis Management Advisor Skill

A downloadable skill for emergency preparedness, incident response, crisis leadership, business continuity, recovery, and external coordination.

## Installation
1. Download and extract `emergency-crisis-management-skill.zip`.
2. Add the complete extracted folder to the skills directory supported by your Copilot or agent environment.
3. Keep the folder structure unchanged.
4. Validate all contacts, authorities, notification periods, maps, equipment, tactics, and legal requirements for the applicable site and jurisdiction.

## Example Requests
- Develop an Emergency Response Plan for an integrated fertilizer complex.
- Create a fire, toxic gas, and chemical spill scenario register.
- Design a site evacuation, shelter, and accountability plan.
- Prepare an ammonia release tabletop exercise with injects and evaluation criteria.
- Establish an incident command structure and role cards.
- Draft a strategic crisis management plan for senior leadership.
- Build a business continuity dependency and recovery register.
- Create an authority and mutual-aid coordination register.
