# Incident Command Role Cards

## Incident Commander
- Confirm command and location
- Establish initial objectives and priorities
- Approve protective actions and incident action arrangements
- Maintain responder and public safety
- Coordinate command transfer and stand-down

## Safety Function
- Identify responder hazards and unsafe conditions
- Advise command on controls and withdrawal
- Monitor responder welfare, PPE, decontamination, and exposure interfaces
- Record urgent safety concerns

## Operations
- Implement approved tactical objectives
- Organize teams and maintain accountability
- Report progress, hazards, resource needs, and control status

## Planning
- Maintain situation status, forecasts, maps, logs, and action planning
- Track objectives, resources, unresolved issues, and handover

## Logistics
- Provide personnel, equipment, communications, transport, welfare, and supplies
- Track availability, limitations, and replenishment

## Liaison
- Coordinate agencies, authorities, mutual aid, hospitals, utilities, and contractors
- Maintain contact and information exchange records

## Public Information or Communications
- Coordinate approved internal and external messages
- Maintain consistency, authorization, and records

These are generic role prompts requiring alignment with the approved site and jurisdictional structure.
