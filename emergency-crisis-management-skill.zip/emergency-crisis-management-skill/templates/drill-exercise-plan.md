# Emergency Drill or Exercise Plan

## Exercise Details
- Title:
- Type:
- Date and location:
- Scenario:
- Scope and exclusions:
- Exercise director:
- Controllers and evaluators:

## Objectives
| ID | Measurable objective | Expected evidence | Evaluator |
|---|---|---|---|

## Safety and Control
- Real-emergency override:
- Stop or pause criteria:
- Simulated actions and prohibited actions:
- Participant welfare and operational safeguards:

## Scenario Timeline and Injects
| Time or trigger | Inject | Delivery method | Expected consideration |
|---|---|---|---|

## Evaluation
Assess command, communications, protective actions, accountability, resources, external coordination, crisis interface, continuity, and recovery.

## Debrief and Actions
| ID | Strength or gap | Evidence | Corrective action | Owner | Due date | Effectiveness check |
|---|---|---|---|---|---|---|
