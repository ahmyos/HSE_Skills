# Crisis Situation Report

- Incident:
- Report number:
- Reporting period:
- Prepared by:
- Approved by:

## 1. Current Situation
## 2. People and Welfare
## 3. Operational and Environmental Status
## 4. Incident Command Objectives and Constraints
## 5. Authorities and External Agencies
## 6. Stakeholder and Media Position
## 7. Business Continuity and Critical Services
## 8. Key Risks and Forecast
## 9. Decisions Required
## 10. Actions and Owners
## 11. Next Update Trigger
