# Evacuation and Accountability Plan

## Protective Action Basis
- Scenarios requiring evacuation:
- Scenarios requiring shelter-in-place or refuge:
- Activation authority:
- Alarm signals and backup notification:

## Routes and Locations
- Primary and alternate routes:
- Muster or refuge locations:
- Accessibility arrangements:
- Adverse wind, weather, smoke, or route impairment considerations:

## Accountability
| Group | Accountability method | Responsible role | Backup method | Missing-person escalation |
|---|---|---|---|---|
| Employees | | | | |
| Contractors | | | | |
| Visitors | | | | |
| Drivers | | | | |
| Responders | | | | |

## Re-entry
- Authorization:
- Safety and environmental verification:
- Communication method:
