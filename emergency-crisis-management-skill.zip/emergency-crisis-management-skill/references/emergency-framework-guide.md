# Emergency and Crisis Framework Guide

## Distinct Management Layers
- Emergency response: immediate protective and stabilizing actions
- Incident command: on-scene objectives, tactics, resources, safety, and coordination
- Crisis management: strategic decisions, stakeholders, reputation, legal, financial, and enterprise consequences
- Business continuity: continuation and recovery of prioritized products, services, and activities
- Recovery: safe restoration, remediation, support, investigation, and improvement

## Reference Starting Points
Verify applicability and jurisdiction before use:
- Applicable fire, civil defense, occupational safety, environmental, emergency, security, and notification requirements
- National or local incident-management doctrine
- Business continuity management system standards
- Site permits, hazard studies, insurer requirements, and mutual-aid agreements
- Manufacturer instructions and current SDS

## Unsuitable Shortcuts
- A contact list presented as an emergency plan
- Evacuation maps without accountability arrangements
- Teams named without competence, equipment, or alternates
- Drills conducted without objectives or corrective actions
- Crisis teams that duplicate or override on-scene command
- Continuity plans without business impact and dependency information
