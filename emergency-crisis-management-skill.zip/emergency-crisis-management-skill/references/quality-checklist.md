# Emergency and Crisis Management Quality Checklist

- [ ] Credible scenarios and escalation potential are defined
- [ ] Life-safety priorities and prohibited actions are clear
- [ ] Command, alternates, handover, and decision authority are defined
- [ ] Alarm, notification, and backup communications are addressed
- [ ] Evacuation, shelter, accountability, missing persons, and re-entry are covered
- [ ] Fire, rescue, medical, spill, security, and environmental interfaces are covered
- [ ] External services, authorities, hospitals, utilities, and mutual aid are verified
- [ ] Equipment, competence, maintenance, inspection, and resource limitations are visible
- [ ] Crisis management does not interfere with incident command
- [ ] Business continuity priorities and dependencies are evidence-based
- [ ] Exercises have measurable objectives and safe controls
- [ ] Actions have owners, due dates, evidence, and effectiveness verification
- [ ] Contacts, maps, layouts, inventories, and annexes are current
- [ ] Legal notification periods and agencies are not invented
- [ ] Recovery, investigation, welfare, and lessons learned are included
- [ ] Revision, distribution, confidentiality, and review triggers are controlled
