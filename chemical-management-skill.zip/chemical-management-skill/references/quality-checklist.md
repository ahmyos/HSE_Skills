# Chemical Management Quality Checklist

- [ ] Chemical identity, supplier, concentration, and intended use are clear
- [ ] Current SDS and label information are available and consistent
- [ ] Applicable jurisdiction and site requirements are identified
- [ ] Full life cycle has been considered
- [ ] Routine, non-routine, abnormal, and emergency scenarios are addressed
- [ ] Exposure routes and environmental pathways are complete
- [ ] Compatibility conclusions are verified or explicitly pending specialist review
- [ ] Controls follow the hierarchy of controls
- [ ] Engineering controls, containment, ventilation, and detection are addressed
- [ ] PPE is task-specific and not copied without evaluation
- [ ] Storage, transfer, waste, emergency, and medical interfaces are covered
- [ ] Owners, approvals, actions, and evidence are visible
- [ ] No hazard classification, limit, treatment, or legal claim is invented
- [ ] Residual risks and unresolved information are clearly stated
- [ ] Review date, revision, and document-control fields are included
