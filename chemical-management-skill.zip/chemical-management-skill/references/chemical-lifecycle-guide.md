# Chemical Life-Cycle Guide

## Governance Interfaces
Chemical management may interface with:
- HSE management systems
- Process safety and management of change
- Occupational hygiene and medical surveillance
- Fire protection and emergency response
- Environmental permits and waste management
- Procurement, stores, logistics, and supplier assurance
- Quality, product stewardship, and customer requirements
- Transport of dangerous goods
- Contractor management
- Security and restricted substances

## Reference Frameworks
Verify applicability, adoption, edition, and jurisdiction before use:
- Globally Harmonized System of Classification and Labelling of Chemicals
- Applicable national hazard communication and worker-protection requirements
- Applicable environmental, hazardous waste, transport, fire, and civil-defense rules
- Occupational health and safety and environmental management system frameworks
- Supplier SDS, technical data, certificates, and emergency information
- Site permits, licenses, process safety studies, and corporate standards

## Escalation Triggers
Seek specialist review for:
- Highly toxic inhalation hazards
- Reactive or unstable chemistry
- Scale-up, substitution, or supplier composition change
- Bulk inventory increase
- New storage tank or lining selection
- Pressurized, refrigerated, or cryogenic chemicals
- Explosives, organic peroxides, pyrophorics, water-reactives, or self-heating materials
- Carcinogens, mutagens, reproductive toxins, sensitizers, or substances of special concern
- Significant community, environmental, or major accident consequences
