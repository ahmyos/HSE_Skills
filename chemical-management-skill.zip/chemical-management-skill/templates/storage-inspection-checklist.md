# Chemical Storage Inspection Checklist

## Area Details
- Area:
- Inspector:
- Date:
- Responsible department:

## Checks
- [ ] Access is controlled and signage is legible
- [ ] Inventory matches approved holdings
- [ ] Containers are compatible, closed, and undamaged
- [ ] Original and workplace labels are legible
- [ ] No unknown or unlabelled chemicals are present
- [ ] Chemicals are segregated by verified compatibility
- [ ] Secondary containment is suitable and available
- [ ] Floors, drains, and drainage isolation are satisfactory
- [ ] Ventilation and detection systems are operational where required
- [ ] Ignition sources and hazardous-area controls are managed
- [ ] Shelving, pallets, racks, tanks, and supports are sound
- [ ] Temperature, sunlight, moisture, and weather controls are suitable
- [ ] Spill kits, eyewash, showers, and firefighting provisions are accessible
- [ ] SDS and emergency information are accessible
- [ ] Waste and empty containers are correctly controlled
- [ ] Inspection, testing, and maintenance records are current

## Findings and Actions
| ID | Finding | Risk | Immediate control | Corrective action | Owner | Due date | Status |
|---|---|---|---|---|---|---|---|
