# Chemical Risk Assessment

## 1. Assessment Details
- Chemical or product:
- Concentration:
- SDS revision:
- Task or process:
- Location:
- Persons exposed:
- Assessor and team:
- Date and review date:

## 2. Task Description and Conditions

## 3. Hazard and Exposure Assessment
| Step | Hazardous property | Exposure or release scenario | Receptor | Existing preventive controls | Existing mitigative controls | Inherent risk | Additional controls | Residual risk | Evidence |
|---|---|---|---|---|---|---|---|---|---|

## 4. Compatibility and Reaction Review

## 5. Occupational Hygiene Requirements

## 6. Storage, Transfer, and Containment

## 7. Emergency, Fire, Spill, and Medical Arrangements

## 8. Environmental and Waste Controls

## 9. Actions and Approvals
| ID | Action | Owner | Priority | Due date | Completion evidence | Effectiveness review |
|---|---|---|---|---|---|---|
