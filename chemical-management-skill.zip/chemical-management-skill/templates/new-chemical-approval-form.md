# New or Changed Chemical Approval Form

## 1. Request Details
- Request ID:
- Department:
- Requester:
- Product name:
- Manufacturer or supplier:
- Intended use:
- Location:
- Trial, temporary, or permanent:
- Estimated and maximum quantity:

## 2. Information Submitted
- [ ] Current SDS
- [ ] Technical data sheet
- [ ] Composition or certificate
- [ ] Transport information
- [ ] Waste and disposal information
- [ ] Supplier emergency contact

## 3. Alternatives Review
- Can the need be eliminated?
- Is a less hazardous substitute available?
- Reason for selection:

## 4. HSE Review
| Review area | Finding | Required control or condition | Owner | Status |
|---|---|---|---|---|
| Hazard classification | | | | |
| Exposure and hygiene | | | | |
| Compatibility and process safety | | | | |
| Storage and containment | | | | |
| Handling and transfer | | | | |
| Fire and emergency | | | | |
| Environmental impact | | | | |
| Waste and disposal | | | | |
| Legal and permit | | | | |
| Training and competency | | | | |

## 5. Decision
- [ ] Approved
- [ ] Approved with conditions
- [ ] Trial approval only
- [ ] Rejected
- [ ] Pending information

Conditions and restrictions:

Approvers and dates:
