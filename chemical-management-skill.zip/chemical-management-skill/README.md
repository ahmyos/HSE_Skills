# Chemical Management Advisor Skill

A reusable skill package for full life-cycle chemical management in industrial and technical workplaces.

## Installation
1. Download and extract `chemical-management-skill.zip`.
2. Add the complete extracted folder to the skills directory supported by your Copilot or agent environment.
3. Keep the folder structure unchanged.
4. Validate legal, permit, transport, exposure-limit, emergency, medical, and waste requirements for the applicable jurisdiction and site.

## Example Requests
- Review this Safety Data Sheet and create a gap and action matrix.
- Build a chemical register for a fertilizer complex.
- Prepare a new chemical approval workflow and form.
- Assess storage compatibility and identify items requiring specialist verification.
- Draft a chemical handling and life-cycle management procedure.
- Create a task-specific chemical risk assessment for acid unloading.
- Develop a chemical warehouse inspection checklist.
- Prepare an executive chemical management audit report.

## Authoritative Reference Starting Points
- UNECE Globally Harmonized System of Classification and Labelling of Chemicals
- Applicable national hazard communication and worker-protection rules
- Applicable environmental, hazardous waste, and dangerous-goods transport requirements
- Current supplier Safety Data Sheets and technical data
