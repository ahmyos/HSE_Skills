# HSE Risk Management Advisor Skill

A reusable skill package for workplace, environmental, project, contractor, process, and operational HSE risk management.

## Installation
1. Download and extract `hse-risk-management-skill.zip`.
2. Add the complete extracted folder to the skills directory supported by your Copilot or agent environment.
3. Keep the folder structure unchanged.
4. Replace proposed risk criteria with the organization’s formally approved matrix, escalation rules, and acceptance authorities.

## Example Requests
- Build a baseline HIRA for a fertilizer plant covering construction and operations.
- Create a JSA for sulphuric acid unloading.
- Review this risk assessment for weak controls and unjustified residual-risk reduction.
- Develop a bow-tie and critical-control register for ammonia loss of containment.
- Create an environmental risk register for phosphogypsum handling and storage.
- Assess EPC interfaces, battery limits, and commissioning risks.
- Prepare a management-of-change risk review.
- Produce an executive material-risk profile and action plan.

## Reference Starting Points
- ISO 31000 risk management guidelines
- ISO 45001 occupational health and safety management systems
- ISO 14001 environmental management systems
- Applicable legal, permit, client, lender, insurer, and corporate requirements
- Approved site risk matrix and risk-acceptance authority
