# HSE Risk Method Guide

## Recommended Decision Logic
- Broad scope and early phase: HAZID or baseline HIRA
- Step-based work: JSA/JHA or task risk assessment
- Process deviation: HAZOP by competent multidisciplinary team
- Top event and barrier management: bow-tie
- Equipment failure: FMEA
- Environmental significance: aspect-impact and source-pathway-receptor assessment
- Exposure uncertainty: occupational hygiene assessment
- High-consequence decision requiring numerical justification: specialist semi-quantitative or quantitative method

## Control Hierarchy
1. Eliminate
2. Substitute
3. Engineering controls
4. Administrative controls
5. Personal protective equipment

## Common Failure Modes
- Hazard stated as consequence only
- Generic controls without owners or standards
- Risk reduced before actions are implemented
- One assessment copied across different tasks or locations
- No worker participation
- Emergency and abnormal modes omitted
- No change or review trigger
- Overreliance on PPE, training, or signage
- Multiple unrelated hazards in one row
- No link between findings, actions, and verification
