# HSE Risk Assessment Quality Checklist

- [ ] Purpose, boundaries, and decision are clear
- [ ] Applicable criteria and acceptance authority are defined
- [ ] Assessment team has relevant operational and technical competence
- [ ] Workers or task performers were consulted where applicable
- [ ] Work is broken into meaningful stages or scenarios
- [ ] Normal, abnormal, maintenance, startup, shutdown, and emergency modes are considered
- [ ] Hazard, cause, event, consequence, and receptor are distinct
- [ ] Environmental and occupational-health risks are included
- [ ] Existing controls are specific and evidence-based
- [ ] Preventive and mitigative barriers are distinguished
- [ ] Hierarchy of controls is applied
- [ ] Ratings use the approved matrix consistently
- [ ] Planned actions have not been treated as completed controls
- [ ] Owners, due dates, evidence, and effectiveness checks are defined
- [ ] High and material risks are escalated appropriately
- [ ] Assumptions, uncertainties, and data gaps are visible
- [ ] Review triggers and next review date are recorded
- [ ] Final residual risk and acceptance status are authorized
