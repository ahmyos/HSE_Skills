# Risk Acceptance and Escalation Framework

## Purpose
Define who may accept residual HSE risk and under what evidence, time, and control conditions.

## Proposed Structure Requiring Organizational Approval
| Risk band | Minimum response | Interim control requirement | Permanent action expectation | Acceptance authority | Review frequency | Escalation trigger |
|---|---|---|---|---|---|---|
| Low | Maintain controls | As applicable | Routine improvement | [Define] | [Define] | Control degradation or change |
| Medium | Improvement plan | Required where exposure remains | Time-bound treatment | [Define] | [Define] | Overdue action or repeated event |
| High | Senior escalation and restricted work | Immediate verified controls | Urgent risk reduction | [Define] | [Define] | Any control failure or change |
| Extreme | Do not start or stop work unless emergency life-safety action is authorized | Isolation and emergency control | Redesign or eliminate before routine work | [Define] | Continuous until reduced | Immediate executive notification |

## Acceptance Record
- Risk ID:
- Decision and justification:
- Controls verified:
- Uncertainty and limitations:
- Interim controls:
- Required actions:
- Acceptance authority:
- Acceptance period or review date:
- Evidence:
