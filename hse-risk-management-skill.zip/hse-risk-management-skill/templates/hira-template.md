# Hazard Identification and Risk Assessment

## Assessment Details
- Project or site:
- Area or activity:
- Scope:
- Assessment team:
- Applicable procedure and matrix:
- Date:
- Next review:
- Assumptions and limitations:

## Risk Assessment
| ID | Task or scenario | Hazard | Cause or threat | Event or exposure | Consequence and receptor | Existing controls | Inherent risk | Additional controls | Residual risk | Owner | Due date | Evidence and review |
|---|---|---|---|---|---|---|---|---|---|---|---|---|

## Approval and Acceptance
- Prepared by:
- Reviewed by:
- Approved by:
- Residual-risk acceptance authority:
