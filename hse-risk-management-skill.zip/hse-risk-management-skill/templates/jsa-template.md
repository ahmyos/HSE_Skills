# Job Safety Analysis / Job Hazard Analysis

## Job Details
- Job:
- Location:
- Work group and contractor:
- Supervisor:
- Required permits:
- Tools, equipment, and chemicals:
- Related procedures and drawings:
- Emergency arrangements:

## Job Steps
| Step | Work step | Hazard and cause | Potential consequence | Existing or required controls | Responsible person | Residual risk | Stop-work or hold point |
|---|---|---|---|---|---|---|---|

## Pre-Job Confirmation
- [ ] Workforce briefed and understands the job
- [ ] Conditions match the assessment
- [ ] Controls and emergency arrangements are in place
- [ ] Interfaces and simultaneous operations are controlled
- [ ] Changes trigger reassessment

Signatures or approved electronic acknowledgment:
