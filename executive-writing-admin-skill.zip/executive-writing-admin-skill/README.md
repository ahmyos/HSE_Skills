# Executive Writing and Administration Advisor Skill

A reusable skill package for professional business writing and comprehensive administrative support.

## Installation
1. Download and extract `executive-writing-admin-skill.zip`.
2. Add the complete extracted folder to the skills directory supported by your Copilot or agent environment.
3. Keep the folder structure unchanged so all templates and references remain available.
4. Align filing, retention, confidentiality, approval, and administrative practices with your organization’s approved policies.

## Example Requests
- Rewrite this email in a concise executive tone and provide three options.
- Turn these notes into a management-ready weekly report.
- Review this procedure for grammar, duplication, role clarity, governance gaps, and release readiness.
- Create meeting minutes with a separate decision and action register.
- Build a document-control register and file-naming convention.
- Prepare an administrative checklist for an executive site visit.
- Draft a formal reminder for overdue deliverables without sounding aggressive.
