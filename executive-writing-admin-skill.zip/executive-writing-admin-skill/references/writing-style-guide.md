# Business Writing Style Guide

## Preferred Style
- Lead with purpose and outcome.
- Use precise, familiar words.
- Keep paragraphs focused on one idea.
- Use active voice where responsibility is known.
- Replace vague wording with an observable action or result.
- Remove repetition, unnecessary background, and inflated language.

## Word Choices
Prefer:
- “Please approve” instead of “Kindly be informed that your approval is requested”
- “We completed” instead of “It has been completed by us”
- “The report identifies” instead of “The report talks about”
- “Due by [date]” instead of “at the earliest convenience”

## Control Words
- Shall: mandatory internal requirement
- Should: recommendation
- May: permission or possibility
- Must: unavoidable or externally imposed requirement, used carefully

## Common Review Risks
- Incorrect names or titles
- Conflicting dates or figures
- Unclear pronouns
- Undefined abbreviations
- Missing attachments
- Unclear decision authority
- Actions without owners or due dates
- Claims without evidence
- Inconsistent status terms
- Mixed document versions
