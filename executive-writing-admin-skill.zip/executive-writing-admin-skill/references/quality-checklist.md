# Writing and Administration Quality Checklist

## Content
- [ ] Purpose is clear
- [ ] Requested outcome appears early
- [ ] Facts, assumptions, proposals, and decisions are distinguished
- [ ] Names, titles, dates, figures, and references are accurate
- [ ] No unsupported commitments or claims
- [ ] Risks, dependencies, and open items are visible

## Structure
- [ ] Logical headings and sequence
- [ ] No duplication or contradiction
- [ ] Tables and lists are used appropriately
- [ ] Cross-references and numbering are correct
- [ ] Attachments and appendices are identified

## Language
- [ ] Tone fits the audience
- [ ] Sentences are clear and concise
- [ ] Grammar, spelling, punctuation, and capitalization are correct
- [ ] Terms and abbreviations are consistent
- [ ] No vague deadlines or ownership

## Administration and Control
- [ ] Owner, reviewer, approver, revision, and status are clear where applicable
- [ ] Actions include confirmed owners and due dates
- [ ] Confidentiality and distribution are appropriate
- [ ] File name and version are suitable
- [ ] Closure evidence or approval is identified where required
