# Administrative Checklists

## Meeting Coordination
- [ ] Purpose and desired decisions defined
- [ ] Date, time, location, and access details confirmed
- [ ] Required participants identified
- [ ] Agenda and pre-reads prepared
- [ ] Equipment, room, or platform requirements checked
- [ ] Minutes and action tracker prepared
- [ ] Decisions and actions distributed after the meeting

## Business Travel
- [ ] Approval requirement identified
- [ ] Traveler details verified
- [ ] Itinerary and business purpose documented
- [ ] Visa, passport, insurance, and site-access needs flagged
- [ ] Accommodation and ground transport requirements listed
- [ ] Emergency contacts and host details recorded
- [ ] Expense and document-retention requirements checked

## Visitor or Event Coordination
- [ ] Visitor details and host confirmed
- [ ] Access approval and identification requirements checked
- [ ] Safety, security, induction, and PPE needs identified
- [ ] Room, catering, equipment, and transport requirements listed
- [ ] Confidentiality or photography restrictions communicated
- [ ] Attendance record and follow-up actions prepared

## Document Issue
- [ ] Correct template used
- [ ] Document ID and title verified
- [ ] Revision and status updated
- [ ] Review and approval completed
- [ ] Distribution list checked
- [ ] File name and format confirmed
- [ ] Superseded version controlled
- [ ] Register updated

## New Starter Administration
- [ ] Approval and start details confirmed
- [ ] Workspace, equipment, accounts, and access requests listed
- [ ] Induction and required training scheduled or requested
- [ ] Policies, role documents, and contacts prepared
- [ ] Manager and support functions notified
- [ ] Probation or onboarding checkpoints recorded

## Handover
- [ ] Active priorities summarized
- [ ] Upcoming deadlines listed
- [ ] Key contacts identified
- [ ] Open actions and risks transferred
- [ ] Documents and storage locations referenced
- [ ] Access or approval dependencies flagged
- [ ] Escalation requirements recorded
