# Management Report

## Document Control
- Report title:
- Reporting period:
- Prepared by:
- Reviewed by:
- Approved by:
- Revision:
- Status:

## 1. Executive Summary

## 2. Purpose and Scope

## 3. Key Progress and Achievements

## 4. Performance and Evidence
| Measure | Current result | Target or baseline | Status | Commentary |
|---|---|---|---|---|

## 5. Key Issues, Risks, and Impacts
| ID | Issue or risk | Impact | Current control | Owner | Required support |
|---|---|---|---|---|---|

## 6. Decisions Required

## 7. Action Plan
| ID | Action | Owner | Due date | Status | Evidence or update |
|---|---|---|---|---|---|

## 8. Priorities for the Next Period

## 9. Appendices and References
