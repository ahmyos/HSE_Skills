# Meeting Minutes

## Meeting Details
- Meeting title:
- Date and time:
- Location or platform:
- Chair:
- Minute taker:
- Purpose:

## Attendees and Apologies
Record only confirmed information.

## Agenda and Discussion Summary
| Item | Topic | Summary | Decision or outcome |
|---|---|---|---|

## Decisions
| ID | Decision | Decision owner or authority | Reference |
|---|---|---|---|

## Actions
| ID | Action | Owner | Due date | Priority | Status | Evidence or update |
|---|---|---|---|---|---|---|

## Open Issues and Parking Lot

## Next Meeting
Include only if confirmed.
