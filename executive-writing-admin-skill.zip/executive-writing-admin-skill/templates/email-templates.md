# Email Templates

## 1. Approval Request
**Subject:** Approval Required: [Item] by [Date]

Dear [Name],

Please review and approve [item/purpose]. The key point requiring your decision is [decision].

[Brief context and implications.]

**Requested action:** [Approve / comment / select option] by [confirmed or proposed date].

Best regards,
[Name]

## 2. Follow-Up
**Subject:** Follow-Up: [Item or Action]

Dear [Name],

I am following up on [item] to confirm the current status and next step.

Please provide [specific response or deliverable]. This is required to support [business reason].

Best regards,
[Name]

## 3. Executive Update
**Subject:** Update: [Topic] | [Status]

Dear [Name],

[One-sentence status and significance.]

**Completed:** [Key result]

**Open issue:** [Risk or dependency]

**Next step:** [Action, owner, and confirmed date if available]

Best regards,
[Name]

## 4. Diplomatic Correction
**Subject:** Correction: [Topic or Reference]

Dear [Name],

Please note the following correction to [email/document/reference]: [correct information].

The remaining content is unchanged. Please use this correction for all further action.

Best regards,
[Name]
