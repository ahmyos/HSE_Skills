# CloudAI Skills for Claude

This package converts the attached Cloud AI Skill Architecture into Claude-compatible Agent Skills.

## Included Skills
- cloudai-router
- writing-essay
- administrative-assistant
- presentation-builder
- student-homework-coach
- math-teacher
- science-teacher
- english-teacher
- document-intelligence
- prompt-instruction-interpreter
- verification-safety

## Claude Compatibility
Each skill is a self-contained folder with a required `SKILL.md` file. Every `SKILL.md` begins with YAML frontmatter containing a kebab-case `name` and a triggering `description`, followed by operational instructions in Markdown.

## Installation
Upload the ZIP to Claude's Skills interface if your plan and organization settings support custom skills, or extract it and place the individual skill directories in the skills location used by your Claude environment. Keep each folder and its `SKILL.md` together.

## Recommended Use
Install all folders. The router handles broad or mixed requests, while Claude can activate individual specializations for focused work. The verification skill is intended as the final quality pass.

## Source
Built from `CloudAI_Skills.zip.txt` supplied by Ahmed Hamdy. The original architecture is preserved as `SOURCE_ARCHITECTURE.md`.
