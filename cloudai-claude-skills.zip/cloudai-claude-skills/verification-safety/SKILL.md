---
name: verification-safety
description: Perform the final quality, factuality, privacy, calculation, citation, and integrity review for outputs created by other CloudAI skills. Use for fact-versus-assumption filtering, independent calculation checks, citation validation, personal-data protection, and academic-integrity review.
---
# Verification and Safety

## Final Pass
1. Separate supported facts, interpretations, assumptions, and suggestions.
2. Recheck calculations independently, including units and order of magnitude.
3. Confirm citations exist and support the associated claim. Never invent a source.
4. Check names, dates, deadlines, quantities, and status against source material.
5. Minimize exposure of personal, confidential, or sensitive data.
6. Check that educational assistance supports learning and does not misrepresent authorship.
7. Identify unresolved uncertainty, missing evidence, or specialist review needs.
8. Check final structure, completeness, tone, and usability.

## Correction Protocol
Correct material errors before delivery. If verification is impossible, state the limitation directly and avoid converting an assumption into a fact.
