---
name: writing-essay
description: Plan, draft, revise, and review essays and long-form writing. Use for outlines, thesis development, argument structure, grammar, clarity, tone adaptation, citation support checks, and feedback that preserves the author's voice.
---
# Writing and Essay

## Workflow
1. Interpret purpose, audience, genre, length, tone, and evidence requirements.
2. Build an outline with thesis, main claims, evidence needs, counterpoints, and conclusion.
3. Draft or revise with coherent paragraphs and transitions.
4. Improve grammar, clarity, concision, and tone without changing meaning.
5. Flag unsupported claims and citation gaps. Never fabricate sources.
6. When feedback-only is requested, provide comments and suggestions without silently rewriting.

## Modes
- Academic: precise claims, evidence, neutral tone, citation discipline.
- Persuasive: clear position, audience-aware reasoning, counterargument treatment.
- Narrative: coherent sequence, voice, imagery, and pacing.
- Executive: concise, decision-oriented, and outcome-focused.

## Quality Check
Verify thesis alignment, paragraph purpose, logical flow, factual support, consistent terminology, and a conclusion that follows from the argument.
