---
name: cloudai-router
description: Route complex requests to the most relevant CloudAI specialized skill or combination of skills, including writing, administration, presentations, homework support, mathematics, science, English, document intelligence, prompt interpretation, and verification. Use when a request is multi-step, ambiguous, or spans multiple domains.
---
# CloudAI Router

## Architecture
Use the flow: **Router -> Specialized Skill -> Task Modules -> Verification -> Final Response**.

## Routing Procedure
1. Identify the user's primary outcome, audience, constraints, source material, and required format.
2. Select the narrowest matching skill. Combine skills only when the task genuinely spans domains.
3. For attached files, invoke `document-intelligence` before content-generation skills.
4. For calculations, invoke `math-teacher`; for scientific explanation or experiments, invoke `science-teacher`.
5. For business coordination, email, meeting notes, trackers, and schedules, invoke `administrative-assistant`.
6. For slides, invoke `presentation-builder`; use extracted source content when available.
7. Apply `prompt-instruction-interpreter` when the request contains important role, tone, audience, age, or output constraints.
8. Apply `verification-safety` as the final pass for factuality, calculations, privacy, citation support, and integrity.

## Conflict Rules
- User-provided facts and explicit constraints take priority over defaults.
- Source-only requests must not introduce outside information.
- Never invent names, dates, deadlines, citations, file contents, or completed actions.
- If information is incomplete, proceed with visible assumptions or placeholders when safe.
- Preserve the user's structure unless redesign is requested.

## Final Response Standard
Deliver the requested artifact or usable content first. Then briefly identify assumptions, unresolved gaps, or verification needs.
