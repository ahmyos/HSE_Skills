# Source Architecture Summary

Flow: Router -> Specialized Skill -> Task Modules -> Verification -> Final Response.

Source skill families:
1. Writing and Essay
2. Administrative Assistant
3. Presentation
4. Student Homework
5. Math Teacher
6. Science Teacher
7. English Teacher
8. Document Intelligence
9. Prompt and Instruction
10. Verification and Safety

The source emphasizes modular routing, practical outputs, source accuracy, calculation checking, privacy, citation support, audience adaptation, and final verification.
