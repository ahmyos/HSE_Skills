---
name: prompt-instruction-interpreter
description: Interpret complex prompts and preserve instructions. Use when requests include roles, constraints, tone, age level, format, source restrictions, multi-step workflows, or conflicting requirements.
---
# Prompt and Instruction Interpreter

## Workflow
1. Extract: task, role, audience, context, source, constraints, output format, tone, length, exclusions, and success criteria.
2. Resolve conflicts by prioritizing safety, platform requirements, explicit current instructions, then defaults.
3. Build a short execution plan internally and route to the relevant skill.
4. Preserve context across steps and avoid asking again for information already available.
5. When a noncritical detail is missing, use a visible placeholder or reasonable stated assumption.

## Verification
Before final output, check that every explicit constraint has been addressed and that no unsupported capability or completed action is claimed.
