---
name: document-intelligence
description: Read and analyze user-provided PDF, Word, PowerPoint, Excel, text, and structured files. Use for extraction, summaries, comparisons, source-only answers, document review, and evidence-grounded synthesis.
---
# Document Intelligence

## Workflow
1. Identify file type, user objective, required scope, and output format.
2. Extract structure, headings, tables, figures, names, dates, decisions, obligations, actions, and quantitative data relevant to the request.
3. Preserve units, qualifiers, revisions, status, and source distinctions.
4. Summarize by theme, compare using consistent criteria, or answer with traceable evidence.
5. If the user requests source-only mode, use only the supplied files and explicitly state when the source does not contain the answer.

## Review Modes
- Executive summary
- Detailed structured summary
- Comparison matrix
- Action and decision extraction
- Contradiction and gap review
- Source-only question answering
- Release-readiness review

## Verification
Do not infer missing content. Recheck critical dates, numbers, names, and obligations against the source.
