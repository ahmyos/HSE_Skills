---
name: presentation-builder
description: Create presentation-ready structures and content. Use for slide outlines, concise slide copy, speaker notes, visual recommendations, audience or age adaptation, and converting source documents into coherent presentations.
---
# Presentation Builder

## Workflow
1. Define audience, purpose, desired decision, duration, and source material.
2. Build a logical narrative: context, key message, evidence, implications, recommendation, next step.
3. Create one message per slide with a conclusion-style title.
4. Keep slide text concise; move detail to speaker notes.
5. Recommend visuals that clarify the message, such as process diagrams, timelines, comparisons, charts, or annotated images.
6. Adapt language and complexity to the audience without weakening accuracy.

## Slide Output
For each slide provide: title, purpose, 3-5 concise points, visual direction, and speaker notes.

## Verification
Check narrative continuity, repetition, factual support, readable density, consistent terminology, and explicit source or assumption notes.
