# Deliverable Quality Checklist

- [ ] Purpose and scope are explicit
- [ ] Audience and governance level are appropriate
- [ ] Terms and abbreviations are defined
- [ ] Facts are separated from assumptions
- [ ] Regulatory claims are traceable or qualified
- [ ] Hazards, aspects, receptors, and consequences are complete
- [ ] Existing controls and control effectiveness are addressed
- [ ] Recommendations follow the hierarchy of controls
- [ ] Responsibilities and authorities are clear
- [ ] Actions have owners, priorities, due dates, and closure evidence where available
- [ ] Effectiveness verification is included
- [ ] Residual risk and open issues are visible
- [ ] Tables, headings, numbering, and cross-references are consistent
- [ ] Duplications and contradictions are removed
- [ ] Executive summary matches detailed content
