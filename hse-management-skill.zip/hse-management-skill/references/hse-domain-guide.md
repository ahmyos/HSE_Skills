# HSE Domain Guide

## Suggested Framework References
Use only when applicable and verify the current edition and jurisdiction before relying on them:
- Occupational health and safety management system frameworks
- Environmental management system frameworks
- Risk management principles
- Incident investigation and root cause analysis methods
- Process safety management and major accident prevention frameworks
- Local labor, environmental, civil defense, hazardous materials, waste, transport, and permitting requirements
- Client, lender, insurer, contractual, and corporate standards

## Hierarchy of Controls
1. Elimination
2. Substitution
3. Engineering controls
4. Administrative controls
5. Personal protective equipment

## Risk-Based Prioritization
Prioritize actions considering:
- Potential severity
- Likelihood or exposure
- Number and vulnerability of receptors
- Legal or permit breach
- Control reliability
- Escalation potential
- Detectability
- Urgency and feasibility

## Finding Classification
- Critical: Immediate serious risk or significant legal exposure requiring urgent control
- Major: Systemic or high-risk weakness requiring prioritized corrective action
- Minor: Limited nonconformity or localized weakness
- Observation: Improvement opportunity without confirmed nonconformity
- Good practice: Effective control worth sustaining or replicating
