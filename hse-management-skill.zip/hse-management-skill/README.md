# HSE Management Advisor Skill

A reusable skill package covering:
- HSE management systems
- Incident investigation
- Environmental management
- Regulatory and compliance management
- Risk, audit, contractor, emergency, and performance management

## Installation
1. Download and extract `hse-management-skill.zip`.
2. Add the extracted skill folder to the skills directory supported by your Copilot or agent environment.
3. Keep the folder structure unchanged so the templates and references remain available.
4. Review and adapt jurisdiction-specific legal content before operational use.

## Example Requests
- Review this incident report and identify evidence gaps, failed barriers, and corrective actions.
- Create an environmental management plan for phosphogypsum handling and storage.
- Build a legal and permit compliance register for a fertilizer plant.
- Assess an EPC contractor proposal against HSE management requirements.
- Draft a management-ready HSE monthly performance summary.
