# HSE Management System Gap Assessment

## Rating Scale
- Conforming
- Partially conforming
- Nonconforming
- Not applicable
- Not verified

| Element | Requirement or expected control | Evidence reviewed | Status | Risk | Gap | Recommendation | Owner | Due date |
|---|---|---|---|---|---|---|---|---|
| Leadership and policy | | | | | | | | |
| Legal and other requirements | | | | | | | | |
| Risk and aspect management | | | | | | | | |
| Operational control | | | | | | | | |
| Contractor management | | | | | | | | |
| Emergency preparedness | | | | | | | | |
| Competence and communication | | | | | | | | |
| Incident and corrective action | | | | | | | | |
| Monitoring and assurance | | | | | | | | |
| Management review | | | | | | | | |
