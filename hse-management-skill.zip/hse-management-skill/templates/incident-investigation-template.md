# Incident Investigation Report

## 1. Executive Summary

## 2. Incident Details
- Date and time:
- Location:
- Activity:
- Incident type:
- Actual consequence:
- Potential consequence:
- Notification status:

## 3. Immediate Actions

## 4. Scope and Investigation Team

## 5. Evidence Reviewed

## 6. Confirmed Timeline

## 7. Event and Barrier Analysis
| Stage | Event or condition | Expected barrier | Barrier status | Evidence |
|---|---|---|---|---|

## 8. Causes
### 8.1 Immediate Causes
### 8.2 Contributing Factors
### 8.3 Root or Systemic Causes

## 9. Findings

## 10. Corrective and Preventive Action Plan
| No. | Cause or barrier gap | Required action | Owner | Priority | Due date | Completion evidence | Effectiveness review |
|---|---|---|---|---|---|---|---|

## 11. Lessons Learned

## 12. Approval and Closeout
