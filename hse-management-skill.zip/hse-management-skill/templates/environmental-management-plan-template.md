# Environmental Management Plan

## 1. Purpose
## 2. Scope
## 3. Site and Process Description
## 4. Legal, Permit, and Other Requirements
## 5. Roles and Responsibilities
## 6. Environmental Aspects and Impacts
| Activity | Aspect | Condition | Impact | Receptor | Existing controls | Significance | Additional controls |
|---|---|---|---|---|---|---|---|

## 7. Operational Controls
### 7.1 Air Emissions and Dust
### 7.2 Water and Effluent
### 7.3 Waste Management
### 7.4 Chemicals and Fuels
### 7.5 Soil and Groundwater
### 7.6 Noise and Vibration
### 7.7 Resource and Energy Use
### 7.8 Community Impacts
### 7.9 Biodiversity and Land

## 8. Monitoring and Measurement
| Parameter | Location | Method | Frequency | Limit or trigger | Responsible role | Record | Response |
|---|---|---|---|---|---|---|---|

## 9. Emergency Preparedness and Response
## 10. Competence and Training
## 11. Communication and Complaints
## 12. Inspection, Audit, and Corrective Action
## 13. Reporting and Record Retention
## 14. Management Review and Improvement
