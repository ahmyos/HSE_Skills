# Process Safety Method Guide

## Method Selection
- HAZID: broad early identification of major hazards
- HAZOP: systematic review of deviations from design intent
- What-if/checklist: structured questioning where appropriate
- FMEA: equipment or component failure modes
- LOPA: semi-quantitative review of a single cause-consequence scenario
- SIL determination: required risk reduction for a candidate safety instrumented function
- QRA: specialist quantitative assessment for complex major-risk decisions
- Bow-tie: communication and assurance of threats, consequences, and barriers

## Independent Protection Layer Screening
A candidate IPL should be assessed against approved criteria for:
- Independence
- Functionality
- Integrity
- Reliability
- Auditability
- Access security and impairment control
- Management of change

## Common Study Weaknesses
- Outdated P&IDs or incomplete design basis
- Generic causes and consequences
- Safeguard double counting
- Crediting alarms without defined response time and reliability basis
- Treating operator training or procedure alone as an IPL without approved justification
- Ignoring common utilities and common-cause failure
- Excluding startup, shutdown, maintenance, bypass, or abnormal operation
- Closing actions without engineering evidence
- Assigning SIL without separating determination from verification
