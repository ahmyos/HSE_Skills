# Process Safety Management Advisor Skill

A downloadable skill package for systematic prevention and control of major process incidents.

## Installation
1. Download and extract `process-safety-management-skill.zip`.
2. Add the complete folder to the skills directory supported by your Copilot or agent environment.
3. Keep the folder structure unchanged.
4. Replace placeholders and proposed criteria with approved site methods, verified engineering data, applicable legal requirements, and competent specialist studies.

## Example Requests
- Prepare HAZOP terms of reference and a node worksheet for a sulphuric acid plant.
- Review a HAZOP report for weak safeguards, missing modes, and recommendation quality.
- Build a LOPA worksheet without assigning unverified frequency or PFD values.
- Create a SIL determination record and Safety Requirements Specification structure.
- Assess a fertilizer complex against an integrated PSM framework.
- Develop a major accident hazard and critical-control register for ammonia, sulfur, acids, and toxic gases.
- Review loss-of-containment prevention and mechanical integrity controls.
- Prepare a PSSR checklist for commissioning and startup.
- Structure an emergency depressurization engineering review.
