# Pre-Startup Safety Review

## Project or Change
- Unit or system:
- MOC or project reference:
- Planned introduction of hazardous material or energy:
- Review team:

## Verification
- [ ] Construction and equipment conform to approved design
- [ ] Process safety information and drawings are current
- [ ] PHA recommendations required before startup are closed
- [ ] Relief, flare, vent, drain, and containment pathways are verified
- [ ] Alarms, trips, interlocks, ESD, and SIS are tested and documented
- [ ] Operating limits, procedures, and emergency shutdown are approved
- [ ] Mechanical integrity baselines and inspections are complete
- [ ] Utilities, fire protection, detection, communications, and emergency response are ready
- [ ] Operators, maintainers, contractors, and responders are competent
- [ ] Chemicals, SDS, PPE, occupational hygiene, and waste controls are ready
- [ ] Open items are risk-assessed, authorized, and controlled

## Decision
- [ ] Ready for startup
- [ ] Ready with formally approved limitations
- [ ] Not ready

Approvals and evidence:
